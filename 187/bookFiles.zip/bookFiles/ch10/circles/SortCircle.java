package ch10.circles;

public class SortCircle
{
  public int xValue;
  public int yValue;
  public int radius;
  public boolean solid;
} 
